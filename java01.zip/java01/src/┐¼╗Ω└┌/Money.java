package ������;

public class Money {

	public static void main(String[] args) {
		int mymoney=20000;
		int bromoney=30000;
		
		System.out.println(mymoney>bromoney);
		System.out.println(mymoney<bromoney);
	}

}
