package java08;

import java.util.ArrayList;

public class ��Ű��ȸ {

	public static void main(String[] args) {
		ArrayList list = new ArrayList();
		list.add("�ڽ�Ű");
		list.add("�۽�Ű");
		list.add("�轺Ű");
		list.add("����Ű");
		list.remove(1);
		System.out.println(list);
		
	}

}
