package java08;

import javax.swing.JOptionPane;

public class StaticTest {

	public static void main(String[] args) {
		String year=JOptionPane.showInputDialog("�¾ �ظ� �Է�");
		int y=Integer.parseInt(year);
		System.out.println(2019-y+1);
		
		
		
	}

}
