package java08;

import java.util.ArrayList;

public class ����ȯ2 {

	public static void main(String[] args) {
		ArrayList list = new ArrayList();
		list.add("ȫ�浿");
		list.add(100);
		list.get(0);
		String name=(String)list.get(0);
		Integer num=(Integer)list.get(1);
		
		
	}

}
