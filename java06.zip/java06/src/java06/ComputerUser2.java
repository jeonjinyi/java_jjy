package java06;

public class ComputerUser2 {

	public static void main(String[] args) {
		Computer c1 = new Computer(100,"samsung");
		System.out.println(c1);
	}

}
