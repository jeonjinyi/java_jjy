package �迭;

public class Test1 {

	public static void main(String[] args) {
		int age=100;
		System.out.println(age);
		
		
	}

}
