package �迭;

public class �迭���ڴ��ϱ� {

	public static void main(String[] args) {
		int[] num= {10,20,30,40,50};
		System.out.println(num[0]+num[1]);
		
		
	}

}
